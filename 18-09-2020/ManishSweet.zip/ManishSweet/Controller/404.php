<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Manish Sweet Pvt Ltd | Rajkot | Ahemdabad | Surat | 404 page not found</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo $baseurl;?>css/bootstrap.min.css'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo $baseurl;?>css/font-awesome.min.css'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo $baseurl;?>css/style.css'>
    <link rel='icon' type='text/css' media='screen' href='<?php echo $baseurl;?><?php echo $baseurl;?>images/logo.png'>
    <script src='<?php echo $baseurl;?>js/jquery.js'></script>
    <script src='<?php echo $baseurl;?>js/cycle.min.js'></script>

    <script src='<?php echo $baseurl;?>js/bootstrap.min.js'></script>

</head>

<body>
  
  
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-xs-12">
                <center>
                <img src="<?php echo $baseurl;?>images/404.png" style="width: 80%;  height: 400px;">

                <a href="<?php echo $mainurl;?>"><button type="button" class="btn btn-danger" style="width:450px; height:55px; border-radius:0px; font-size:18px">Don't Worry want to Go on Home Page Click Here >></button></a>
                </center>
                 
                </div>
                </div>
                </div>

    </div>

    <div class=" clearfix"></div>



</body>
</html>