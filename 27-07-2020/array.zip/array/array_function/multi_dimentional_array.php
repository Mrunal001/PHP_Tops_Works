<?php
$arr=array("technical"=>array("php","java","python","asp.net","ios","android"),("nontechnical")=>array("seo","dm","gd","wd","st"));

print_r($arr);
print_r($arr["technical"][0]);
print_r($arr["nontechnical"][3]);



?>