
    <!-- Register modals created here -->
    <div class="modal fade" id="reg" role="dialog" style=" overflow:auto !important">
        <div class="modal-dialog" style="width: 70%;">
            <div class="modal-content" style="height: 1200px;">

                <div class="col-md-6 col-xs-12" style="background-color:rgba(195, 8, 8, 0.3); height: 1200px;" id="login-sidebar">
                    <h3 align="center" style="color:white; letter-spacing: 2px;">
                        <span class="fa fa-birthday-cake"></span> Why Join With Manish Sweet</h3>
                    <hr style=" border:solid 2px white ">
                    <ul>
                        <li><a href="# "><span class="fa fa-birthday-cake"></span> Gathiya 24X7 Garma Garam</a></li>

                        <li><a href="# "><span class="fa fa-male"></span> 24X7 Service Available</a></li>

                        <li><a href="# "><span class="fa fa-truck"></span> 24X7 Home Dellivery</a></li>

                        <li><a href="# "><span class="fa fa-map-marker"></span> 10 Offices in Gujrat</a></li>

                        <li><a href="# "><span class="fa fa-credit-card"></span> Online Payment Accepted</a></li>

                    </ul>

                </div>

                <div class="col-md-6 col-xs-12 ">

                    <h3 align="center">Register Here</h3>
                    <hr style="border:solid 2px gray">

                    <form method="POST" enctype="multipart/form-data">
                    
                    
                        <div class="form-group">
                            <input type="file" name="img" placeholder="Photo *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>


                        <div class="form-group">
                            <input type="text" name="em" placeholder="Email *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>

                        <div class="form-group">
                            <input type="password" name="pass" placeholder="Password *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>

                        <div class="form-group">
                            <input type="password" name="cpass" placeholder="Confirm Password *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>

                        <div class="form-group">
                            <input type="text" name="fname" placeholder="Firstname *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>


                        <div class="form-group">
                            <input type="text" name="lname" placeholder="Lastname *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>


                        
                        <div class="form-group">
                            <input type="number" name="mob" placeholder="Mobile *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>


                        
                        <div class="form-group">
                            <input type="number" name="pin" placeholder="Pincode *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>


                        
                        <div class="form-group">
                            <textarea name="add" placeholder="Address *" required style="border-bottom:red solid 2px; height: 150px;" class="form-control"></textarea>
                        </div>


                        
                        <div class="form-group">
                            Male <input type="radio" name="gender"  value="male" style="border-bottom:red solid 2px; height:auto;">

                            Female <input type="radio" name="gender"  value="female" style="border-bottom:red solid 2px; height:auto;">

                        </div>




                        
                        <div class="form-group">
                            <select name="country" placeholder="Country *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                            <option value="">-select country-</option>
                            
                            <?php
                             
                             foreach ($cn as $cn1) {
                                 ?>
                            
                            <option value="<?php echo $cn1["cid"];?>"> <?php echo $cn1["cname"];?> </option>
                            <?php
                             }

                             ?>
                            </select>
                        </div>

                        
                        <div class="form-group">
                            <select name="state" placeholder="State *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                            <option value="">-select State-</option>
                            <?php
                            foreach ($sn as $sn1) {
                                ?>
                            <option value="<?php echo $sn1["sid"]; ?>"><?php echo $sn1["sname"]; ?></option>
                            
                            <?php
                            }
                            ?>


                            </select>
                        </div>


                        <div class="form-group">
                            <select name="city" placeholder="City *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                            <option value="">-select city-</option>
                            
                            <?php
                              
                              foreach ($ct as $ct1) 
                              {
                                  ?>

                            <option value="<?php echo $ct1["ctid"];?>"><?php echo $ct1["ctname"];?></option>
                               

                            <?php
                              }
?>
                              
                            </select>
                        </div>


                        <div class="form-group">
                            <input type="submit" name="reg" style="border-bottom:red solid 2px; height: 50px;; border:none; border-radius:0px 0px 0px 0px; width: 150px;" value="Register" class="btn btn-info btn-lg">
      
                            <input type="reset" name="res" style="border-bottom:red solid 2px; height: 50px;; border:none; border-radius:0px 0px 0px 0px; width: 150px;" value="Reset" class="btn btn-danger btn-lg">
                            <br><br>
                            <br>
                            <center>
                            <b><a href="#" data-toggle="modal" data-target="#myacc" data-dismiss="modal">Have an   Account ? Login Here</a></b>
                           </center>

                        </div>

                    </form>

                </div>



            </div>

        </div>
    </div>
