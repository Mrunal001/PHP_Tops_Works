 <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2020</p>
    </div>
    <!-- /.container -->
  </footer><?php /**PATH D:\xampp\htdocs\shopclues_laravel\resources\views/blogs/inc/footer.blade.php ENDPATH**/ ?>