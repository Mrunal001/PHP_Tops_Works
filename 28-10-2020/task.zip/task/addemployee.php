<div class="modal fade" role="dialog" id="addemp">
    <div class="modal-dialog" style="width: 80%;">
        <div class="modal-content" style="height: 590px;">

            <div class="col-md-12 col-xs-12">



                <div class="col-md-4 col-xs-12">
                    <h3 align="center">Add Employee</h3>
                    <hr style="width:50%; border:solid 2px gray">
                    <img src="<?php echo $baseurl;?>images/emp.png">
                </div>




                <div class="col-md-8 col-xs-12">
                    <h3 align="center">Form</h3>
                    <hr style="width:50%; border:solid 2px gray">
                </div>



            </div>





        </div>
    </div>
</div>