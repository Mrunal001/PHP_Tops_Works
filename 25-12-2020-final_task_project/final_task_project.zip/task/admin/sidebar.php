<!-- content start here -->
<div class="content">
    <!-- <div class="container-fluid"> -->
    <div class="row">
        <div class="col-md-12 col-xs-12">

<div class="col-md-3 col-xs-12" id="sidebar" style="">

<a href="<?php echo $mainurl;?>Dashboard"><img src="<?php echo $baseurl;?>images/users.png" class="img img-circle" style="width: 100px; height: 100px; border:solid 1px gray; padding:15px; margin-left:19%"></a>


<ul>
    <li><a href="<?php echo $mainurl;?>ManageStudent">Manage All Student <span class="fa fa-users" style="color: red;"></span></a></li>
    <li><a href="<?php echo $mainurl;?>AddStudentImages">Add Gallery <span class="fa fa-comment" style="color: red;"></span></a></li>

    <li><a href="<?php echo $mainurl;?>AddCourse">Add Course <span class="fa fa-book" style="color: red;"></span></a></li>
    
    <li><a href="<?php echo $mainurl;?>ManageContact">Manage Contact <span class="fa fa-phone" style="color: red;"></span></a></li>
    <li><a href="<?php echo $mainurl;?>ManageFeedback">Manage Feedback <span class="fa fa-comment" style="color: red;"></span></a></li>

    <li><a href="<?php echo $mainurl;?>AddCountry">Add Country <span class="fa fa-map-marker" style="color: red;"></span></a></li>
    <li><a href="<?php echo $mainurl;?>AddState">Add State <span class="fa fa-map-marker" style="color: red;"></span></a></li>
    <li><a href="<?php echo $mainurl;?>AddCity">Add City <span class="fa fa-map-marker" style="color: red;"></span></a></li>
    <li><a href="<?php echo $mainurl;?>ManagePayments">Manage Payments <span class="fa fa-money" style="color: red;"></span></a></li>
    <li><a href="<?php echo $mainurl;?>Dashboard?lg">Logout Here <span class="fa fa-power-off" style="color: red;"></span></a></li>
</ul>


</div>



            <!-- sidebar start here -->
          


               
