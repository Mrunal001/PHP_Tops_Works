function printt() {

    document.getElementById("btn").style = "display:none";
    window.print();

}