<?php

//array_count_values():

$arr=array("php",".net","java","php","php","python","java","python");
print_r(array_count_values($arr));


?>