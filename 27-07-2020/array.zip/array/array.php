<?php
// 0=>"banana"
// key     value
// [0]=>"apple"
// key   value

$arr=array(0=>"sagar",1=>"maulik",2=>"brijesh",3=>"nimesh",4=>"jinesh");
//echo $arr;
print_r($arr);




?>