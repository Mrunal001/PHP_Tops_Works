<?php
class a
{
     public function test();
    
}
class b
{
     public function test1();
    
}

class c
{
     public function test2();
    
}

class d extends a,b,c
{


    #note : not supported multiple inheritance
}