<!-- content start here -->
<div class="content">
    <!-- <div class="container-fluid"> -->
    <div class="row">
        <div class="col-md-12 col-xs-12">
            <!-- sidebar -->




            <!-- content panel start here -->
            <div class="col-md-12 col-xs-12" id="content-panel">

          
            <div class="col-md-4 col-xs-12">
                    <div class="well wll-lg">
                        <h4><a href="#" style="color: black;" data-toggle="modal" data-target="#addemp"><span class="fa fa-plus-circle"></span> Manage Online Course</a></h4>
                    </div>

                </div>

                <div class="col-md-4 col-xs-12">
                    <div class="well wll-lg">
                        <h4><span class="fa fa-plus-circle"></span> Online Support and Practical Solved Query</h4>
                    </div>

                </div>

                <div class="col-md-4 col-xs-12">
                    <div class="well wll-lg">
                        <h4><a href="<?php echo $mainurl;?>ManageAllCourse"><span class="fa fa-address-book"></span> Total Course <span class="badge badge-lg" style="background-color: red; color: white;">
                     
                        <?php
                         
                         echo $countsubj[0]["total"];

                        ?>
                    
                    
                    </span> </a></h4>
                    </div>

                </div>

                <!-- content area of employee -->
                <div class="col-md-12 col-xs-12 col-md-offset-0">
                    <h2 align="center">Who we are?</h2>
                    <hr style="width: 50%; border: solid 2px lightskyblue;">

                    <p align="justify" style="width: 80%; margin-left: 10%;">


                        <p align="justify">
                            <span style="font-size: 19px; text-align: 45px;">Techno Tasks,</span> Inc is global company headquartered in Farmers Branch ,TX and off-shore in Hyderabad. We are unique company with different wings. Our main focuses are IT
                            Staffing and unique Digital Marketing.<br></p>

                        <p align="justify">IT Staffing based in Farmers Branch, TX has been providing contract and permanent staffing services throughout USA. Our focus and dedication to local talent acquisition on your behalf remains the primary reason for our success.
                            <br>
                        </p>


                        <p align="justify">We help companies source and hire the most qualified information technology, accounting / finance, administrative / clerical, and supply chain professionals. We work hand in hand with your Human Resources team, hiring managers
                            or Managed Service Provider (“MSP”) to improve the effectiveness and efficiency of your recruitment processes. Our ability to source and recruit superior talent is rivaled only by our deep commitment to servicing our client’s
                            recruitment needs. We strive to differentiate ourselves by providing a level of service unparalleled in the industry.</p>
                    </p>


                    <p align="justify">


                        <ul style="font-weight: bold;">
                            <li>Dedicated Account Managers who serve as your single point of contact.</li>
                            <li> Experienced local Technical Recruiters qualify candidates based on your requirements.</li>

                            <li>Trained professional staff who stay abreast of emerging technologies and staffing trends.</li>

                            <li>Flexible business approach that works within your guidelines. </li>
                            <li>
                                Selective, stringent and confidential recruiting process. </li>

                            <li>Access to passive job seekers.</li>
                            <li> Our business philosophy is simple. We understand our client’s needs, our candidate’s career goals and provide the best match possible.</li>

                        </ul>


                    </p>

                    <p align="justify">The unique Digital Marketing sources which balance creativity with feasibility. We at Techno Tasks want to create success stories of brands that glow brightest in the digital space. It is a Global based digital marketing organization
                        specializing in helping businesses grow their online company through digital marketing. Focusing in custom web solutions via website designing and implementation, SMM, SEO, Google Analytics, Email Marketing, lead generation & marketing
                        automation; Techno tasks have the right ritual solution for your business. We helped many of companies worldwide build their brand, increase their reach and grow their industry through dynamic digital marketing. It was established
                        to help productions change strategic thinking from impulsion marketing to attract or inbound marketing. We work with customers in many verticals including but not limited to automotive, web, manufacturing, service industry, non-profit
                        organizations, and medical professionals. A successful internet marketing campaign involves both creative and technical expertise. We are best in creating marketing plans from the ground up and helping consult businesses in achieving
                        results. Let’s start your journey of successful business with our experts. Techno Tasks is a company built upon corporate confidence. Throughout our years of corporate experience, we have strengthened our ability to quickly satisfy
                        our clients’ IT staff augmentation and project sourcing requirements. Today, we use our formidable force of recruiters to directly support our program, project, and business relationship managers for satisfying our clients’ IT
                        <img src="<?php echo $baseurl;?>images/slider3.jpg" style="width: 450px; height: 250px; float: right; padding:15px"> resource requirements. The culture of Techno Tasks is one of shared success, not just with customers but also
                        with our employees. Making part of the company’s stock available (in the form of stock options) to key Techno Tasks Managers and staff, our founders have made it likely that when you work with a Techno Tasks employee, you’re likely
                        working with a Techno Tasks shareholder with some “skin in the game”. Mission & Vision Techno Tasks’s mission is to use reliable strategies and apply them to distinct specifications to provide quality solutions on time and within
                        budget. Techno Tasks ensures the high quality of each individual within our proposed teams through a rigorous screening process that evaluates potential employees based on specific technological qualifications, training, certifications,
                        and experience. Because internal stability is fundamental to success, Techno Tasks retains expert staff with a combination of incentives and benefits. Involvement, communication, and cooperation are key factors for the success
                        of each of Techno Tasks unique solutions. Each member, from employee to investor, is involved from the first steps of the project life cycle through to its implementation to optimize productivity and the end quality achieved. Involvement,
                        communication, and cooperation are key factors for the success of each of Techno Tasks’s unique solutions. Each member, from employee to investor, is involved from the first steps of the project life cycle through to its implementation
                        to optimize productivity and the end quality achieved. Techno Tasks’s true excellence lies within our ability to look at the “big picture” — to recognize beforehand how each facet of the undertaking will merge within the final
                        incarnation. Our knowledge base is continually expanding to include new information on technology and the organizations that require it.


                    </p>

                    </p>


                </div>



                <!-- 
            </div> -->
            </div>
        </div>
    </div>