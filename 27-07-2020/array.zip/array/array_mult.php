<?php
$arr=array("tech"=>array("php","asp.net","python"),"notech"=>array("wd","st"));

print_r($arr);

?>