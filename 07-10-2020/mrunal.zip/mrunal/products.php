<div class="content">
 <div class="container-fluid">
     <div class="row">
     <div class="col-md-12 col-xs-12">

     <div class="col-md-4 col-xs-12" id="cat-sidebar">
<div class="jumbotron">
<h2 align="center">Select Category</h2>
<hr>
             
<ul>

<li><a href="">Electronics</a></li>

<li><a href="">Home Appliences</a></li>

<li><a href="">Mens Wear</a></li>

<li><a href="">Womens Wear</a></li>

<li><a href="">Kids Wear</a></li>
</ul>




             </div>
         </div>
         




     
     <div class="col-md-8 col-xs-12">

             <h3 style="padding: 15px; background-color: gray; color:white">50% Off on select Items Hurry Up </h3>
             
             
             <div class="col-md-4 col-xs-12">
                 <address>
                     <center>
                  <div class=" thumbnail">
                     <img src="<?php echo $baseurl;?>images/s.webp" style="width:100%; height: 250px;">
                     <b>Rebook Shoes</b><br>
                     <b>Rs.<del>2500-/</del>1500-/</b><br>
                     <b><span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star-half"></span></b><br>
                     <b><button type="button" class="btn btn-sm btn-danger">AddToCart</b>
                  </div>
                    </center>
                    </address>
             </div>
             



             <div class="col-md-4 col-xs-12">
                 <address>
                     <center>
                  <div class=" thumbnail">
                     <img src="<?php echo $baseurl;?>images/s1.webp" style="width:100%; height: 250px;">
                     <b>Rebook Shoes</b><br>
                     <b>Rs.<del>2500-/</del>1500-/</b><br>
                     <b><span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star-half"></span></b><br>
                     <b><button type="button" class="btn btn-sm btn-danger">AddToCart</b>
                  </div>
                    </center>
                    </address>
             </div>



             <div class="col-md-4 col-xs-12">
                 <address>
                     <center>
                  <div class=" thumbnail">
                     <img src="<?php echo $baseurl;?>images/s.webp" style="width:100%; height: 250px;">
                     <b>Rebook Shoes</b><br>
                     <b>Rs.<del>2500-/</del>1500-/</b><br>
                     <b><span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star-half"></span></b><br>
                     <b><button type="button" class="btn btn-sm btn-danger">AddToCart</b>
                  </div>
                    </center>
                    </address>
             </div>
             


             <div class="col-md-4 col-xs-12">
                 <address>
                     <center>
                  <div class=" thumbnail">
                     <img src="<?php echo $baseurl;?>images/s.webp" style="width:100%; height: 250px;">
                     <b>Rebook Shoes</b><br>
                     <b>Rs.<del>2500-/</del>1500-/</b><br>
                     <b><span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star-half"></span></b><br>
                     <b><button type="button" class="btn btn-sm btn-danger">AddToCart</b>
                  </div>
                    </center>
                    </address>
             </div>
             

             <div class="col-md-4 col-xs-12">
                 <address>
                     <center>
                  <div class=" thumbnail">
                     <img src="<?php echo $baseurl;?>images/s.webp" style="width:100%; height: 250px;">
                     <b>Rebook Shoes</b><br>
                     <b>Rs.<del>2500-/</del>1500-/</b><br>
                     <b><span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star-half"></span></b><br>
                     <b><button type="button" class="btn btn-sm btn-danger">AddToCart</b>
                  </div>
                    </center>
                    </address>
             </div>
             

             <div class="col-md-4 col-xs-12">
                 <address>
                     <center>
                  <div class=" thumbnail">
                     <img src="<?php echo $baseurl;?>images/s.webp" style="width:100%; height: 250px;">
                     <b>Rebook Shoes</b><br>
                     <b>Rs.<del>2500-/</del>1500-/</b><br>
                     <b><span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star"></span>
                     <span class="fa fa-star-half"></span></b><br>
                     <b><button type="button" class="btn btn-sm btn-danger">AddToCart</b>
                  </div>
                    </center>
                    </address>
             </div>
             
             

         </div>
     </div>


         </div>
     </div>

     </div>
 </div>    
