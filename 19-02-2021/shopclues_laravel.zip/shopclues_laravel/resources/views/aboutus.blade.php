<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Hello i am using Route in laravel</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>

    <a href="service">Services</a> | <a href="contact">Contact</a> | <a href="name">Name</a> 
    <h2 style="color:red; padding:25px; margin-top:2%">About Us</h2>
<hr style="border:red 1px solid">

    <p align='center'>
        Hi This is a Brijesh Kumar Pandey. I am Taking laravel and expert in laravel and work as a laravel Developer in Tops technology pvt ltd.
    </p>
  

</body>
</html>