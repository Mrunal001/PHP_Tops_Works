<?php $__env->startSection('title_here'); ?>
Admin:Add Technology Page

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                        
                            <div class="card shadow-lg border-0 rounded-lg mt-5" style="padding:15px !important">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Manage Technology</h3>


                                </div>




                                
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                DataTable Example
                            </div>


                            <div class="card-body">

                            <?php if(Session::has('delsuccess')): ?>
                                    <div class="alert alert-success">
                                    
                                    <strong role="alert" class=""><?php echo Session::get('delsuccess'); ?></strong>
                                    
                                    </div>
                                 

                                    <?php endif; ?>
                                    


                                    <?php if(Session::has('updsuccess')): ?>
                                    <div class="alert alert-success">
                                    
                                    <strong role="alert" class=""><?php echo Session::get('updsuccess'); ?></strong>
                                    
                                    </div>
                                 

                                    <?php endif; ?>
                                    
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                            <th>Id</th>
                                                <th>Technology Title</th>
                                                <th>Technology Name</th>
                                                <th>Technology Descriptions</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Id</th>
                                                <th>Technology Title</th>
                                                <th>Technology Name</th>
                                                <th>Technology Descriptions</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </tfoot>
                                        <tbody>

                                        
                                       <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                            <tr>
                                                <td><?php echo e($row->id); ?></td>
                                                <td><?php echo e($row->technology_title); ?></td>
                                                <td><?php echo e($row->technology_name); ?></td>
                                                <td><?php echo e($row->technology_description); ?></td>

                                                <td><a href='<?php echo e(url("ReadTechnology/{$row->id}")); ?>' class="btn btn-dm btn-success">Read</a>|
                                                
                                                <a href='<?php echo e(url("manageaddtechnology/{$row->id}")); ?>' class="btn btn-dm btn-danger" onclick="return confirm('Are You sure to Delete Data')">delete</a>|
                                                <a href='<?php echo e(url("EditAddtechnology/{$row->id}")); ?>' class="btn btn-dm btn-info">Edit</a></td>

                                            
                                            </tr>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
            </main>
        </div>

        </div>  </div>


        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cruidshop\resources\views/admin/manageaddtechnology.blade.php ENDPATH**/ ?>