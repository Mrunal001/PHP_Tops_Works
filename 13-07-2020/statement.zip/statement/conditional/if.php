<?php
#syntax of if statement

// if(condition)

// {

//    statment;

// }

// $a=10;
// if($a<10)

// {
  
//     echo "My name is Brijesh";

// }

$a=30;
$b=20;

if($a>$b)

{
  
    echo "a is greter than b";

}



?>