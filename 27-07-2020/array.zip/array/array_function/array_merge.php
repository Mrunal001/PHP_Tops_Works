<?php
$arr=array("a"=>"mrunal","b"=>"jeet","c"=>"sagar");
$arr1=array("a"=>"mrunal","b"=>"hitesh","c"=>"rajesh","d"=>"jinesh");
$arr2=array("a"=>"maulik","b"=>"ramesh","c"=>"sagar","d"=>"kiran");
print_r(array_merge($arr,$arr1,$arr2));


?>