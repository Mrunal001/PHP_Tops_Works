<?php
$str="Brijesh kumar Pandey"."<br>";

echo str_repeat($str,50);


?>