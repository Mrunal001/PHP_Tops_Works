<?php
$array=array("ind"=>"india","us"=>"usa","sri"=>"srilanka","ch"=>"china");
echo json_encode($array);


?>