 <div class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-xs-12">

                    <h5 align="center">Privacy Policy • Website Design and Development by : PHP Team </h5>

                </div>
            </div>
        </div>
    </div>


   