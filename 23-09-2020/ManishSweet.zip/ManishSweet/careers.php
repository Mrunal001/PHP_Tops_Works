    <!-- Creers   modals created here -->
    <div class="modal fade" id="career" role="dialog">
        <div class="modal-dialog" style="width: 70%;">
            <div class="modal-content" style="height: 500px;">

                <div class="col-md-12 col-xs-12" style="background-color:rgba(155,0,0,0.1); height: 500px;" id="login-sidebar">
                    <h3 align="center" style="color:white; letter-spacing: 2px;">
                        <span class="fa fa-birthday-cake"></span> Why Join With Manish Sweet</h3>
                    <hr style=" border:solid 2px white ">
                    <center>
                   <img src="images/job.jpg" style="width:80%; height:250px">

                   <a href="#"><button class="btn btn-danger btn-block" style="width:450px; height:55px; border:none; border-radius:0px 0px 0px 0px; font-size:20px">Want to Apply For Job Click Here !! <span class="fa fa-thumbs-up"></span></button></a>

</center>
                </div>



            </div>

        </div>
    </div>


