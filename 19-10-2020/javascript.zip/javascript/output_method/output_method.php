<!-- 1)alert()
2)docmument.write()
3)console.log()
4)window.print()
5)document.getElementById() -->