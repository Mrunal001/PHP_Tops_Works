<?php

// print("maulik");

echo "maulik"."<br>"."sanjay"."<br>"."Mrunal";

?>