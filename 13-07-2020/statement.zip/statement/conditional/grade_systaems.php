<?php

$grade="D";
if($grade=="A")
{
    echo "<h2 align='center'>Great You are Topper student &#9786</h2>";
}
elseif($grade=="B")
{
    echo "<h2 align='center'>Great You are Average student &#9786</h2>";
}
elseif($grade=="C")

{
    echo "<h2 align='center'>sorry You are Failed student &#9785</h2>";
}

else

{
    echo "sorry your grade not found try again";
}



?>