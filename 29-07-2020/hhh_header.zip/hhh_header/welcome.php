<?php

echo "<h2 align='center'>Welcome of My site</h2>";


?>