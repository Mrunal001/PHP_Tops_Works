    <div class="slider">
        <div id="slide">
            <img src="<?php echo $baseurl;?>images/slider.jpg">
            <img src="<?php echo $baseurl;?>images/slider1.png">
            <img src="<?php echo $baseurl;?>images/slider2.jpg">
            <img src="<?php echo $baseurl;?>images/slider3.jpg">


        </div>
        <div id="click-more">
            <a href="" data-toggle="modal" data-target="#myacc"><button type="button" class="btn btn-lg btn-success"><span class="fa fa-user"></span> MyAccount</button></a>

            <a href="" data-toggle="modal" data-target="#enq"><button type="button" class="btn btn-lg btn-success"> <span class="fa fa-user"></span> Enquiry Form</button></a>

            <a href=""><button type="button" class="btn btn-lg btn-success"><span class="fa fa-comment-o"></span> Feedback</button></a>

            <a href="" data-toggle="modal" data-target="#career"><button type="button" class="btn btn-lg btn-success"><span class="fa fa-bookb"></span> Careers</button></a>
        </div>
    </div>

    <div class="clearfix"></div>
    <div class="clearfix"></div>
