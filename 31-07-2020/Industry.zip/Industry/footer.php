<div class="footer_top_agileits">
		<div class="container">
		<div class="row foot-lft">
			<div class="col-lg-4 footer_grid">
				<h3>About Us</h3>
				<p>Nam libero tempore cum vulputate id est id, pretium semper enim. Morbi viverra congue nisi vel pulvinar posuere sapien
					eros.
				</p>
			</div>
			<div class="col-lg-4 footer_grid">
				<h3>Latest News</h3>
				<ul class="footer_grid_list">
					<li><span class="fa fa-long-arrow-right" aria-hidden="true"></span>
						<a href="services.html">Lorem ipsum neque vulputate </a>
					</li>
					<li><span class="fa fa-long-arrow-right" aria-hidden="true"></span>
						<a href="services.html">Dolor amet sed quam vitae</a>
					</li>
					<li><span class="fa fa-long-arrow-right" aria-hidden="true"></span>
						<a href="services.html">Lorem ipsum neque, vulputate </a>
					</li>
					<li><span class="fa fa-long-arrow-right" aria-hidden="true"></span>
						<a href="services.html">Dolor amet sed quam vitae</a>
					</li>
					<li><span class="fa fa-long-arrow-right" aria-hidden="true"></span>
						<a href="services.html">Lorem ipsum neque, vulputate </a>
					</li>
				</ul>
			</div>
			<div class="col-lg-4 footer_grid">
				<h3>Contact Info</h3>
				<ul class="address">
					<li><span class="fa fa-map-marker" aria-hidden="true"></span>8088 USA, Honey block, New York City.</li>
					<li><span class="fa fa-envelope" aria-hidden="true"></span><a href="mailto:info@example.com">info@example.com</a></li>
					<li><span class="fa fa-phone" aria-hidden="true"></span>+09187 8088 9436</li>
				</ul>
			</div>
			</div>
			<div class="row footer_grids">
				<div class="col-lg-4 footer_grid_left">
					<h3>Sign up for our Newsletter</h3>
				</div>
				<div class="col-lg-8 footer_grid_right">

					<form action="#" method="post">
						<input type="email" name="Email" placeholder="Enter Email Address..." required="">
						<button type="submit">Submit</button>
					</form>
				</div>
				
			</div>
		</div>
	</div>
	<div class="footer_w3ls">
		<div class="container">
					<div class="footer_bottom1">
						<p>© 2019 Steam Engine. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
					</div>
		</div>
	</div>
	