
<div style="background-color: cadetblue; font-size: 18px; padding:10px; color:white">
<center>
<p style="font-size:25px; letter-spacing: 2px;">This Email send By :<br><b>Cruidshop in Laravel.</b></p>

<p><img src="https://embed-fastly.wistia.com/deliveries/9c85353a926f914df6d193b126374548.webp?image_crop_resized=1280x720" style="height: 175px; width: 95%;"></p>

<p style="color:red">Hi, <br> <b>Customer Name is  :</b> <?php echo e($data['name']); ?> </p>

<p style="color:blue"><b>Customer  email is :</b> <?php echo e($data['email']); ?> </p>

<p style="color:blue"><b>Customer Mobile Number  :</b> <?php echo e($data['mobile']); ?> </p>
<p style="color:blue"><b>Customer Message :</b> <?php echo e($data['subject']); ?> </p>
<p style="color:blue"><b>Customer Message :</b> <?php echo e($data['message']); ?> </p>

<p style="color:blue">This is a send email By customer Please conatct and solve problems of Customers via Email</p>

<b>support@onlineportfolio.byethost14.com</b><br>

<b>All emails will be answered within 24 hours</b><br>

<b>WE ARE HERE FOR YOU</b><br>
<b>(+91)9998003879</b><br>

<b>10:00 a.m. to 7:00 p.m.</b>

</center>

</div>
<?php /**PATH D:\xampp\htdocs\cruidshop\resources\views/mrunal/sendcontact_email.blade.php ENDPATH**/ ?>