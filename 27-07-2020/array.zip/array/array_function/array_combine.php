<?php

//array_combine():
$arr=array(0,1,2,3,4);
$arr1=array("brijesh","maulik","sagar","jay","jinesh");
print_r(array_combine($arr,$arr1)); 

?>

8049486173