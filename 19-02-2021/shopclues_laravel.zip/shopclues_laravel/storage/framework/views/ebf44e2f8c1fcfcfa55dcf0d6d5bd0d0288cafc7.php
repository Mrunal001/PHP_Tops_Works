<?php $__env->startSection('blogstitle'); ?>
Home Page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blogs.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
  <div class="row">
  <!-- Blog Entries Column -->
  <div class="col-md-12 col-xs-12">
    <br><br><br><br><br>
    <div class="col-sm-6" style="float:left">
      <h2>Already Have An Account ?</h2>
      <hr style="border:solid 2px gray">
      <p align="justify">By Creating Account with our website you are able to find more to Upload Notes and downloading Notes with admin Permissions and many More >></p>
      <center>
      <a href="<?php echo e('Login_Auth'); ?>"><button type="button" class="btn btn-sm btn-danger" style="height:45px; font-size:18px; width:220px">Login Here</button></a>
      </center>
    </div>
    <div class="col-sm-6"  style="float:left">
      <h2>REGISTER WITH US</h2>
      <hr style="border:solid 1px gray">


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo Session::get('success'); ?></strong>
            </div>
        <?php endif; ?>
      <form method="post" action="<?php echo e(route('Register.store')); ?>" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group">
          <label>Upload Photo *</label>
          <input type="file" name="img" class="form-control <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('img')); ?>" autocomplete="firstname" autofocus>
          <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>


        <div class="form-group">
          <label>Firstname *</label>
          <input type="text" name="firstname" placeholder="Firstname *" class="form-control <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('firstname')); ?>" autocomplete="firstname" autofocus>
          <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Lastname *</label>
          <input type="text" name="lastname" placeholder="Lastname *" class="form-control <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('lastname')); ?>" autocomplete="lastname" autofocus>
          <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Mobile *</label>
          <input type="text" name="mobile" placeholder="Mobile *" class="form-control <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('mobile')); ?>" autocomplete="mobile" autofocus >
          <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Email *</label>
          <input type="text" name="email" placeholder="Email *" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus >
          <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Gender *</label>
          <select name="gender" class="form-control <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="gender" autofocus >
            <option value="">-selectgender-</option>
            <option value="male" <?php if(old('gender') == "male"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Male</option>
            <option value="female" <?php if(old('gender') == "female"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Female</option>
          </select>
          <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Branch *</label>
          <select name="branch" class="form-control <?php if ($errors->has('branch')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('branch'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="branch" autofocus >
            <option value="">-select branch-</option>
            <option value="computerscience" <?php if(old('branch') == "computerscience"): ?> <?php echo e('selected'); ?> <?php endif; ?>>computer science</option>
            <option value="information technology" <?php if(old('branch') == "information technology"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Information technology</option>
          </select>
          <?php if ($errors->has('branch')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('branch'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Are You *</label>
          <select name="role" class="form-control <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="role" autofocus >
            <option value="">-Are You-</option>
            <option value="student" <?php if(old('role') == "student"): ?> <?php echo e('selected'); ?> <?php endif; ?>>student</option>
            <option value="faculty" <?php if(old('role') == "faculty"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Faculty</option>
          </select>
          <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Password *</label>
          <input type="password" name="password" placeholder="********" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" autocomplete="new-password" >
          <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
          <label>Confirm Password *</label>
          <input type="password" name="password_confirmation" placeholder="********" class="form-control" autocomplete="new-password" >
        </div>



        <div class="form-group">
          <label>Select Country *</label>
          <select name="country" id="country" class="form-control <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="role" autofocus >
            <option value="">-Country-</option>

            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($key); ?>"><?php echo e($country); ?></option>
          
          
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>





        <div class="form-group">
          <label>Select State *</label>
          <select name="state" id="state" class="form-control <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="role" autofocus >
         
          
          
          </select>
          <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>





        <div class="form-group">
          <label>Select City *</label>
          <select name="city" id="city" class="form-control <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autocomplete="role" autofocus >
         
     
          </select>
          <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>






        <input type="submit" name="sub" value="Register" class="btn btn-sm btn-danger" style="height:45px; font-size:18px; width:100px">
      </form>
    </div>
    <!-- Blog Post -->
    <!-- Sidebar Widgets Column -->
  </div>
</div>
</div>




<?php echo $__env->make('blogs.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('blog/user')); ?>/vendor/jquery/jquery.min.js"></script>

<script type="text/javascript">
$("#country").change(function(){ 
var countryID=$(this).val();
//alert('hi')
if(countryID)
{
   $.ajax({

     
      type:"GET",
      url:"<?php echo e(url('get-state-list')); ?>?cid="+countryID,
      success:function(data)
      {
        
        if(data)
        {

                   
           $("#state").empty();
           $("#state").append('<option>select</option>');
           $.each(data,function(key,value){

            $("#state").append('<option value="'+key+'">'+value+'</option>');



           });

        }

        
else
{

  $("#state").empty();
  
}


      }

   });

}


else
{

  $("#state").empty();
  $("#city").empty();

}

});




$('#state').on('change',function(){
var stateID=$(this).val();
if(stateID)
{
   $.ajax({

      
      type:"GET",
      url:"<?php echo e(url('get-city-list')); ?>?sid="+stateID,
      success:function(data)
      {
        
        if(data)
        {
           $("#city").empty();
           $("#city").append('<option>select</option>');

           $.each(data,function(key,value){

            $("#city").append('<option value="'+key+'">'+value+'</option>');



           });

        }

        
else
{

  $("#city").empty();
  
}


      }

   });

}


else
{

 
  $("#city").empty();

}

});





</script>

<?php echo $__env->make('blogs.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/Register.blade.php ENDPATH**/ ?>