<?php
class A
{
   public function A()
   {
      
     $name="hello i am brijesh";
     echo $name;



   }

}

$obj=new A();

?>