<?php $__env->startSection('blogstitle'); ?>
Home Page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blogs.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
<div class="row">
  <!-- Blog Entries Column -->
  
    <div class="col-md-12 col-xs-12">   
    <br><br><br><br><br> 


    
<div class="col-sm-6" style="float:left">
<h2>Already Have An Account ?</h2>
<hr style="border:solid 2px gray">
<p align="justify">By Creating Account with our website you are able to find more to Upload Notes and downloading Notes with admin Permissions and many More >></p>
<center>
<a href="<?php echo e('Login_Auth'); ?>"><button type="button" class="btn btn-sm btn-danger" style="height:45px; font-size:18px; width:220px">Login Here</button></a>
</center>
</div>


<div class="col-sm-6"  style="float:left">
<h2>REGISTER WITH US</h2>
<hr style="border:solid 1px gray">
<form method="post">

<?php echo csrf_field(); ?>


<div class="form-group">
<label>Firstname *</label>
<input type="text" name="fname" placeholder="Firstname *" class="form-control" required>
</div>


<div class="form-group">
<label>Lastname *</label>
<input type="text" name="lname" placeholder="Lastname *" class="form-control" required>
</div>

<div class="form-group">
<label>Contact *</label>
<input type="text" name="mob" placeholder="Contact *" class="form-control" required>
</div>




<div class="form-group">
<label>Email *</label>
<input type="text" name="em" placeholder="Email *" class="form-control" required>
</div>


<div class="form-group">
<label>Password *</label>
<input type="password" name="pass" placeholder="********" class="form-control" required>
</div>

<div class="form-group">
<label>Branch *</label>
<select name="branch" class="form-control" required>
<option value="">-select branch-</option>
<option value="computerscience">computer science</option>

<option value="information technology">Information technology</option>
</select>
</div>



<div class="form-group">
<label>Are You *</label>
<select name="role" class="form-control" required>
<option value="">-Are You-</option>
<option value="student">student</option>

<option value="faculty">Faculty</option>
</select>
</div>

<input type="submit" name="sub" value="Register" class="btn btn-sm btn-danger" style="height:45px; font-size:18px; width:100px">


</form>
</div>






    <!-- Blog Post -->
     <!-- Sidebar Widgets Column -->
 
</div>
    

</div>

</div>



</div>


<?php echo $__env->make('blogs.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('blogs.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/register.blade.php ENDPATH**/ ?>