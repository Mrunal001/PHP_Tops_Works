<?php
class name
{
     public function __construct($fname,$lname)


     {

         echo "My firstname is :$fname"."<br>";
         
         echo "My lastname is :$lname"."<br>";


     }


}

$obj=new name("brijesh","pandey");

?>