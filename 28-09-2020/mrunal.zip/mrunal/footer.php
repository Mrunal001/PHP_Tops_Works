<div class="footer">
    <h3>Copyright@2020 All right reserved.</h3>
</div>