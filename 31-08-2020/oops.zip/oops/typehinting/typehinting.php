<?php
// class a
// {
   
//     public $name="Hello i am Brijesh";

// }

// function display(a $name1)

// {
   
//     echo $name1->name;

// }


// display(new a());


class a
{
   
    public $name="Hello i am Brijesh";

}

function typehint(a $name1)

{
   
    echo $name1->name;

}


typehint(new a());






?>