<?php
$name="brijesh";
echo str_replace($name,"brijesh","rajesh");

?>