<?php
$name="Hello Brijesh";
echo $name1;
?>