<?php
define("name","Brijesh");
echo name1;

?>