

<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-xs-12">


                <h3 align="center" style="float:right; font-size:17px">Coyright@2020 Techno Task Manager systems inc.</h3>
            </div>
        </div>
    </div>
</div>

