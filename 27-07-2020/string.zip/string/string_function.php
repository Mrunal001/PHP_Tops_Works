<?php
#List of string function :
strlen()
strpos()
strstr()
stristr()
str_repeat()
str_replace()
str_shuffle()
str_split()
trim()
ltrim()
rtrim()
base64_encode()
base64_decode()
md5()
sha1()
strtolower()
strtoupper()
strtotime()
ucfirst()
ucwords()
strchr()
chr()
strrev()



?>