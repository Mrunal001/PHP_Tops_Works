<?php
class user_defined
{
   public function user_defined()
   
   {  $a=45;
      $b=65; 
      $c=$a+$b;
      echo "Additions of Numbers :$c";

   }

}


$obj=new user_defined();