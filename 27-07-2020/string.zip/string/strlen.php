<?php

$str="brijesh kumar pandey";
echo strlen($str);

?>