

<div style="background-color: cadetblue; padding:25px; color:white; font-size: 18px;">

    <center>
<h3>Brijesh Technical Guru Email Enquiry Form</h3>

<img src="https://logos.textgiraffe.com/logos/logo-name/Brijesh-designstyle-boots-m.png" style="width: 95%; height: 185px;"><br>

<p>Hi This is a Enquiry Form By Customer</p>
<p><b>Customer name is : <?php echo e($data['name']); ?></b></p>
<p><b>Customer Email : <?php echo e($data['email']); ?></b></p>
<p><b>Customer Mobile Number : <?php echo e($data['mobile']); ?></b></p>
<p><b>Customer Message : <?php echo e($data['message']); ?></b></p>

<p>Have a question? Contact Customer Service Department</p>
<p>support@onlineportfolio.byethost14.com</p>

<p>All emails will be answered within 24 hours</p>

<p>WE ARE HERE FOR YOU</p>
<p>(+91)9998003879</p>
<p>10:00 a.m. to 7:00 p.m.</p>
<p><b>Note :This is a Email Enquiry Form</b></p>
</center>
</div><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/message_email_template.blade.php ENDPATH**/ ?>