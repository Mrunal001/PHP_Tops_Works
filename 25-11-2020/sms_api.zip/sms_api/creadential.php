<?php
error_reporting(0);
define("API_KEY","KJ7Tlt1s7mM-3AsVSceAeFmZYddPCTXuYR9jmMG6jI");
define("MOBILE",$_POST["mob"]);


?>