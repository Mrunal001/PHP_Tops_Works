
<!DOCTYPE html>
<html>

<head>
	<title>Steam Engine an Industrial Category Bootstrap Responsive Web Template | Home :: w3layouts</title>
	<!--/tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Steam Engine Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- //for bootstrap working -->
	<link href="//fonts.googleapis.com/css?family=Work+Sans:200,300,400,500,600,700" rel="stylesheet">

		
</head>

<body>
	<!-- header -->

    <?php
    include_once("header.php");
    ?>

  
<?php
    include_once("menu.php");
    ?>

	<!-- banner -->

    
    <?php
    include_once("slider.php");
    ?>
	<!--//banner -->
		<!-- about -->
	<div class="agile-about w3ls-section text-center" id="about">
		<div class="container">
		<h3 class="heading-agileinfo">Welcome To Industrial<span>That performs mechanical work using </span></h3>
			<div class="agileits-about-grid">
				<p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, sunt in culpa qui officia
					deserunt mollit anim id est laboth. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
					fugiat nulla pariatur sunt in culpa qui .</p>
			</div>
		</div>
	</div>
	<!-- //about -->
	<!-- about-bottom -->
	<div class="agileits-about-btm">
		<div class="container">
			<div class="row w3-flex">
			<div class="col-md-4 ab1 agileits-about-grid1">
				<span class="fa fa-industry" aria-hidden="true"></span>
				<h4 class="agileinfo-head">Steel Work</h4>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
			</div>
			<div class="col-md-4 ab1 agileits-about-grid2">
				<span class="fa fa-arrows  wthree-title-list" aria-hidden="true"></span>
				<h4 class="agileinfo-head">New Ideas</h4>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
			</div>
			<div class="col-md-4 ab1 agileits-about-grid3">
				<span class="fa fa-bar-chart  wthree-title-list" aria-hidden="true"></span>
				<h4 class="agileinfo-head">Innovation</h4>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
				<h5>Sunt in culpa</h5>
				<p>Ncididunt ut labore et enim ad minim.</p>
			</div>
			<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //about-bottom -->
<!-- stats -->
	<div class="stats">
		<div class="container">
		<h3 class="heading-agileinfo">Our Stats<span class="ttt">That performs mechanical work using  </span></h3>
			<div class="row">
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid">
				<span class="fa fa-graduation-cap" aria-hidden="true"></span>
				<h3>Supervisors</h3>
				<p class="counter">45</p>
				
			</div>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid1">
				<span class="fa fa-user" aria-hidden="true"></span>
				<h3>Certified Staff</h3>
				<p class="counter">165</p>
				
			</div>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid2">
				<span class="fa fa-users" aria-hidden="true"></span>
				<h3>Workers</h3>
				<p class="counter">563</p>
				
			</div>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid3">
				<span class="fa fa-trophy" aria-hidden="true"></span>
				<h3>Awards</h3>
				<p class="counter">245</p>
				
			</div>
			</div>
		</div>
	</div>
	<!-- //stats -->
	<!-- services -->
<div class="services">
		<h3 class="heading-agileinfo">What we do<span>That performs mechanical work using  </span></h3>
	<div class="container">
		<div class="row services-top-grids">
			<div class="col-md-4">
				<div class="grid1">
					<span class="fa fa-fire"></span>
					<h4>Commercial Fuel</h4>
					<p>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem </p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="grid1">
					<span class="fa fa-tint"></span>
					<h4>Oil Revolution</h4>
					<p>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem </p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="grid1">
					<span class="fa fa-flask"></span>
					<h4>Shell Chemicals</h4>
					<p>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem </p>
				</div>
			</div>
			
		</div>
		<div class="row services-bottom-grids">
			<div class="col-md-4">
				<div class="grid1">
					<span class="fa fa-lightbulb-o"></span>
					<h4>Power & Energy</h4>
					<p>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem </p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="grid1">
					<span class="fa fa-cogs"></span>
					<h4>Quality Material</h4>
					<p>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem </p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="grid1">
					<span class="fa fa-industry"></span>
					<h4>Industry Chemicals</h4>
					<p>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem </p>
				</div>
			</div>
			
		</div>
	</div>
</div>
<!-- //services -->
	<!-- feedback -->
	<div class="feedback section-w3ls about-w3ls" id="testimonials">
		<div class="feedback-agileinfo">
			<div class="container">
				<h3 class="heading-agileinfo">Testimonials<span class="ttt">That performs mechanical work using  </span></h3>
				<div class="agileits-feedback-grids">
					<div class="row owl-carousel owl-theme">
						<div class="col-md-4 item">
							<div class="feedback-info">
								<div class="feedback-top">
									<p> Sed semper leo metus, a lacinia eros semper at. Etiam sodales orci sit amet vehicula pellentesque. </p>
								</div>
								<div class="feedback-grids">
									<div class="feedback-img">
										<img src="images/test1.jpg" class="img-fluid" alt="" />
									</div>
									<div class="feedback-img-info">
										<h5>Mary Jane</h5>
										<p>Vestibulum</p>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
						</div>
						<div class="col-md-4 item">
							<div class="feedback-info">
								<div class="feedback-top">
									<p> Sed semper leo metus, a lacinia eros semper at. Etiam sodales orci sit amet vehicula pellentesque. </p>
								</div>
								<div class="feedback-grids">
									<div class="feedback-img">
										<img src="images/test3.jpg" class="img-fluid" alt="" />
									</div>
									<div class="feedback-img-info">
										<h5>Peter</h5>
										<p>Vestibulum</p>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
						</div>
						<div class="col-md-4 item">
							<div class="feedback-info">
								<div class="feedback-top">
									<p> Sed semper leo metus, a lacinia eros semper at. Etiam sodales orci sit amet vehicula pellentesque. </p>
								</div>
								<div class="feedback-grids">
									<div class="feedback-img">
										<img src="images/test2.jpg" class="img-fluid" alt="" />
									</div>
									<div class="feedback-img-info">
										<h5>Steven</h5>
										<p>Vestibulum</p>
									</div>
									<div class="clearfix"> </div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //feedback -->
<!-- news -->
	<div class="news">
		<div class="container">  
				<h2 class="heading-agileinfo">News & Events<span>That performs mechanical work using </span></h2>
			<div class="news-agileinfo"> 
				<div class="news-w3row"> 
					<div class="row wthree-news-grids">
						<div class="col-md-5 col-xs-5 datew3-agileits">
							<img src="images/g2.jpg" class="img-fluid" alt=""/>
						</div>
						<div class="col-md-7 col-xs-7 datew3-agileits-info ">
							<h5><a href="#" data-toggle="modal" data-target="#myModal">Sit amet justo vitae</a></h5>
							<h6>3/01/2019</h6>
							<p>Proin euismod vehicula vestibulum. Fusce ullamcorper aliquet dolor id egestas. Nulla leo purus, facilisis non cursus ut, egestas sed ipsum.Fusce ullamcorper aliquet dolor id egestas. Nulla leo purus, facilisis non cursus ut, egestas sed ipsum.Fusce ullamcorper aliquet dolor id egestas. Nulla leo purus, facilisis non cursus ut, egestas sed ipsum.</p>
						</div>
						
					</div>
					
					
					<div class="row wthree-news-grids news-grids-mdl">
						<div class="col-md-5 col-xs-5 datew3-agileits datew3-agileits-fltrt">
							<img src="images/g1.jpg" class="img-fluid" alt=""/>
						</div>
						<div class="col-md-7 col-xs-7 datew3-agileits-info datew3-agileits-info-fltlft">
							<h5><a href="#" data-toggle="modal" data-target="#myModal">Fusce scelerisque</a></h5>
							<h6>5/01/2019</h6>
							<p>Proin euismod vehicula vestibulum. Fusce ullamcorper aliquet dolor id egestas. Nulla leo purus, facilisis non cursus ut, egestas sed ipsum.Fusce ullamcorper aliquet dolor id egestas. Nulla leo purus, facilisis non cursus ut, egestas sed ipsum.Fusce ullamcorper aliquet dolor id egestas. Nulla leo purus, facilisis non cursus ut, egestas sed ipsum.</p>
						</div>
						
					</div>
					
				</div>
				
			</div>
		</div>
	</div>
	<!-- //news -->
   
   <?php
       include_once("footer.php");

    ?>
	<!-- footer -->
	<!-- //footer -->
</body>
</html>