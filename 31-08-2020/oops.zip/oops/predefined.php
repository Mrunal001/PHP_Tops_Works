<?php
class name
{
  public function __construct()
  {
       
    echo "Hi i am Predefined Constructor";

  }



}

$obj=new name();
?>