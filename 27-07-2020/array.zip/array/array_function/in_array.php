<?php
$arr=array(0=>"brijesh",1=>"rajesh",2=>"sagar",3=>"jeet");
if(in_array("maulik",$arr))
{
    echo "available";
}

else
{
    echo "not available";
}

?>