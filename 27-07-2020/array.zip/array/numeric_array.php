<?php

$arr=array("Brijesh","Sagar","Naitik");
print_r($arr);


?>