	<div class="agileits_top_menu">
		<div class="w3l_header_left">
				<ul>
					<li><span class="fa fa-phone" aria-hidden="true"></span> (+91)9998003879</li>
					<li><span class="fa fa-envelope-o" aria-hidden="true"></span> <a href="mailto:sheetal@example.com">info@sheetal.com</a></li>
				</ul>
			</div>
			<div class="w3l_header_right">
				<div class="w3ls-social-icons text-left">
					<a class="facebook" href="#"><span class="fa fa-facebook"></span></a>
					<a class="twitter" href="#"><span class="fa fa-twitter"></span></a>
					<a class="pinterest" href="#"><span class="fa fa-pinterest"></span></a>
					<a class="linkedin" href="#"><span class="fa fa-linkedin"></span></a>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
