    <!-- manage all employee -->

    <div class="col-md-9 col-xs-12" id="content-panel">
  <h2 align="center">Manage All Student</h2>
  <hr style="width:50%; border:solid 1px red">
    <table class="table table-responsive table-stripped table-bordered table-hover" align="center">

<tr>
    <th>#Emplid</th>
    <th>Photo</th>
    <th>Name</th>
    <th>Address</th>
    <th>Salary</th>
    <th>Department</th>
    <th>State</th>
    <th>city</th>

    <th>
        <center>Action</center>
    </th>

</tr>

<tr>
    <td>#Emplid</td>
    <td>Photo</td>
    <td>Name</td>
    <td>Address</td>
    <td>Salary</td>
    <td>Department</td>
    <td>State</td>
    <td>city</td>

    <td colspan="4">
        <a href="#"><button type="button" class="btn btn-sm btn-success">SendWhatsap <span class="fa fa-whatsapp"></span></button></a> |

        <a href="#"><button type="button" class="btn btn-sm btn-danger">Delete <span class="fa fa-trash"></span></button></a> |

        <a href="#"><button type="button" class="btn btn-sm btn-info">Edit <span class="fa fa-edit"></span></button></a>


    </td>

</tr>



</table>


</div>

</div>
</div>