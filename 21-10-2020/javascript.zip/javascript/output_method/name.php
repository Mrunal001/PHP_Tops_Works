<?php
$name="maulik";
$name1="kishan";
$name2="mrunal";

// echo $name."<br>".$name1."<br>".$name2;

// print($name."<br>".$name1."<br>".$name2);

echo $name,$name1,$name2;
// print($name,$name1,$name2);


?>