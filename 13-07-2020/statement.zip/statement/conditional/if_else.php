<?php
// syntax:
// if(condition)
// {
//     statement;
// }
// else
// {
//     statements;
// }

$a=10;
$b=20;


if($a>$b)
{

    echo "a is greater than b";
}

else
{

    echo "a is less than b";
}




?>