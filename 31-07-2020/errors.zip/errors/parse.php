<?php
$name="hi my name is brijesh;
eccho $name;


// functio test()
// {

//     $name="brijesh";

//     echo $name;
// }


// test();


?>