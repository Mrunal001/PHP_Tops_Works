<?php
class abc
{
 public $name="Hello my name is :Krunal";     
 public function display()


 {
       echo $this->name;
 }
     
}

$obj=new abc(); //new abc() is a object of class abc
$obj->display();

?>


