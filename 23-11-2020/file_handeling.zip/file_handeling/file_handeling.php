<?php
// file_handeling :used to read/write/append/file open/file close/file write in php

// file handeling function :

// fopen() :using open any open
// fread() : using read any file
// fgets() : usning get any file
// fwrite() : unsing write on any file
// fclose() : using close any file
// unlink() : for remove your file from folders used this function 



// file Modes in php :

// r:read any file
// w:write on any file
// r+:read/write on any file from start of cusrosr
// w+:read/write on any file but if file does not exist create a new file.
// a+:read/write and append anythong on file

?>