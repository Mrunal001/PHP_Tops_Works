<?php
//array_sum():
$arr=array(5454,45454,5454,5454,5454,5454,5454,5454);
print_r(array_sum($arr));



?>