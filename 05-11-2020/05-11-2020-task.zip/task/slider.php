

        <div class="slider">
            <div id="slide">
                <img src="<?php echo $baseurl;?>images/slider.png">
                <img src="<?php echo $baseurl;?>images/slider1.png">
                <img src="<?php echo $baseurl;?>images/slider2.jpg">
                <img src="<?php echo $baseurl;?>images/slider3.jpg">
                <img src="<?php echo $baseurl;?>images/slider4.jpg">
            </div>
        </div>
