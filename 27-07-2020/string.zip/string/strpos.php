<?php

echo strpos("Tops Technology","Tops")."<br>";
echo strpos("Tops Technology","Technology")."<br>";


?>