json :json stands for javascript object notation 
#javascript : javascript is a client side scripting lanaguage
#json used to provide webservices in json formate

json function :

<!-- there are two types of json function  -->

<!-- json_encode() -->
<!-- json_decode() -->


json_encode() :we use json_encode to covert nonreadable formate of array data in json encode formate


json_decode() :we use json_decode to covert into readable formate of json encode data in json deccode formate




