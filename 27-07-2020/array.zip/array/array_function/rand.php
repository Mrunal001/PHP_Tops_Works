<?php

echo rand(00000,99999)."<br>";
echo mt_rand(11111,999999);


?>