		<div class="content white agile-info">
			<div class="container">	
				<nav class="mnu navbar-light">
					<div class="logo" id="logo">
						<h1><a href="index.php">Sheetal Industry</a></h1>
					</div>
					<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
					<input type="checkbox" id="drop">
                    <ul class="menu">
                        <li class="active"><a href="index.php">Home</a></li>
						<li><a href="about.php">About</a></li>
                        <li><a href="about.php">Products</a></li>
						<li><a href="services.php">Services</a></li>
                        <li><a href="about.php">MyAccount</a></li>
                        <li><a href="gallery.php">Gallery</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
				</nav>
			</div>
		</div>
