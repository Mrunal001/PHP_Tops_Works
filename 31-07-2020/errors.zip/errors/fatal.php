<?php

//require('aboutt.php');

echo strll("hi");

// $strlen="hi";
// echo $strlen;

?>