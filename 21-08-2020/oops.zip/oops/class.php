<?php
class abc
{
 public function display()


 {
       $name="Hello My name is : brijesh";

       echo $name;
 }
     
}

$obj=new abc(); //new abc() is a object of class abc
$obj->display();

?>