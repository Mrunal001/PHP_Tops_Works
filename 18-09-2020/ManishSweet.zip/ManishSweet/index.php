<?php

require_once("Controller/Controller.php");

// require_once("header.php");
// require_once("slider.php");
// require_once("content.php");
// require_once("footer.php");
// require_once("login.php");
// require_once("register.php");



?>