	<div class="banner">
			<div class="container">
					<div class="carousel-caption">
				
						<h3>The steam engine in the <span>Industrial </span></h3>
						<p>Any successful career starts with good Industrial. Together with us you will have deeper knowledge of the subjects</p>
						<div class="agileits-button top_ban_agile">
							<a class="btn btn-primary btn-lg" href="about.html">Read More »</a>
						</div>
					</div>
			</div>
		</div>
