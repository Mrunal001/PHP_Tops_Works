    <!-- myaccount modals created here -->
    <div class="modal fade" id="myacc" role="dialog">
        <div class="modal-dialog" style="width: 70%;">
            <div class="modal-content" style="height: 500px;">

                <div class="col-md-6 col-xs-12" style="background-color:rgba(195, 8, 8, 0.3); height: 500px;" id="login-sidebar">
                    <h3 align="center" style="color:white; letter-spacing: 2px;">
                        <span class="fa fa-birthday-cake"></span> Why Join With Manish Sweet</h3>
                    <hr style=" border:solid 2px white ">
                    <ul>
                        <li><a href="# "><span class="fa fa-birthday-cake"></span> Gathiya 24X7 Garma Garam</a></li>

                        <li><a href="# "><span class="fa fa-male"></span> 24X7 Service Available</a></li>

                        <li><a href="# "><span class="fa fa-truck"></span> 24X7 Home Dellivery</a></li>

                        <li><a href="# "><span class="fa fa-map-marker"></span> 10 Offices in Gujrat</a></li>

                        <li><a href="# "><span class="fa fa-credit-card"></span> Online Payment Accepted</a></li>

                    </ul>

                </div>

                <div class="col-md-6 col-xs-12 ">

                    <h3 align="center">Login Here</h3>
                    <hr style="border:solid 2px gray">

                    <form method="POST">

                        <div class="form-group">
                            <input type="text" name="em" placeholder="Email *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>

                        <div class="form-group">
                            <input type="password" name="pass" placeholder="Password *" required style="border-bottom:red solid 2px; height: 40px;" class="form-control">
                        </div>


                        <div class="form-group">
                            <input type="submit" name="log" style="border-bottom:red solid 2px; height: 50px;; border:none; border-radius:0px 0px 0px 0px; width: 150px;" value="Login" class="btn btn-info btn-lg">
                            <b><a href="#" data-target="#frgpass" data-toggle="modal" data-dismiss="modal">Forget Password ?</a></b>
                            <br>

                            <b><a href="#" data-toggle="modal" data-target="#reg" data-dismiss="modal">Don't Have an Account ? Create Account Here</a></b>


                            <h3 align="center" style="color:gray">--------OR----------</h3>
                        </div>

                        <div class="form-group">
                            <button type="button" class="btn-lg btn-danger" style="width: 35%; border:none"><span class="fa fa-google-plus" style="font-size:25px"></span></button> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                            <button type="button" class="btn-lg btn-info" style="width: 35%; border:none"><span class="fa fa-facebook" style="font-size:25px"></span></button>
                        </div>
                    </form>

                </div>



            </div>

        </div>
    </div>

    <!-- create account modal closed here -->

