<div class="content">
 <div class="container-fluid">
     <div class="row">
     <div class="col-md-12 col-xs-12">

     <div class="col-md-4 col-xs-12">
             <div class="jumbotron">
<h2 align="center">Cruid MVC</h2>

<hr>
                
             <p align="justify">
             <h2>MVC in PHP</h2>
PHP MVC is an application design pattern that separates the application data and business logic (model) from the presentation (view). MVC stands for Model, View & Controller. The controller mediates between the models and views. Think of the MVC
</p>
             </div>
         </div>
         




     
     <div class="col-md-8 col-xs-12">
             <div class="jumbotron">

             <form method="post">
             <div class="form-group">
                 <input type="text" name="em" placeholder="Email *" required class="form-control">
             </div>

             
             <div class="form-group">
                 <input type="password" name="pass" placeholder="Password *" required class="form-control">
             </div>



             
             <div class="form-group">
                 <input type="submit" name="log"  class="btn btn-lg btn-info">
                 <b><a href="#">Forget Password ?</a></b>
             </div>


             
             <div class="form-group">
              <h4>Dont Have an Account <a href="<?php echo $mainurl;?>Register">Create Your Account</a></h4>   

             </div>
             
         
         </div>
     </div>


         </div>
     </div>

     </div>
 </div>    
