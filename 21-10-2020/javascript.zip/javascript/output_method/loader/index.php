<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Online Pets Systems Provide Service for All Pets | Rajkot | Ahemdabad</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>

<body>
    <div id="loader"></div>

    <!-- main divisons start -->

    <div id="mydiv">

        <h1 align="center">We hard work to Comming Soon!</h1>
        <p align='center'>Please Like , subscrive us obn youtube <a href="">Brijesh Pandey</a></p>



    </div>
</body>

</html>