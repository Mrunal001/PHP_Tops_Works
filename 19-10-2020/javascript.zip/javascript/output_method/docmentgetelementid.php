<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title></title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script type="text/javascript">
        function ef() {
            document.getElementById("para").style = "font-size:35px;color:red; transition:1s ease all; margin-left:35%";
        }
    </script>
</head>

<body>

    <button type="button" id="btn" onclick="ef()">Click Button</button>
    <p id="para">Hello :Mrunal</p>

</body>

</html>