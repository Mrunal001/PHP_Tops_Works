<?php

$arr=array(0=>"sagar",1=>"maulik",2=>"brijesh",3=>"nimesh",4=>"jinesh");
$arr1=array("a"=>"sagar","b"=>"maulik","c"=>"brijesh","d"=>"nimesh","e"=>"jinesh");

//echo $arr;
//print_r($arr);

print_r($arr1);



?>