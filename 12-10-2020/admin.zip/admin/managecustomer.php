
<!DOCTYPE html>
<head>
<title>Visitors an Admin Panel Category Bootstrap Responsive Website Template | Responsive_table :: w3layouts</title>
</head>
<body>
<section id="container">
<!--header start-->
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
 <div class="panel panel-default">
    <div class="panel-heading">
     Manage Our Customer
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">ID</th>
            <th>Our Customer</th>
            
            <th data-breakpoints="xs">Action</th>
           
            <!-- <th data-breakpoints="xs sm md" data-title="DOB">Date of Birth</th> -->
          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td><?php echo $_SESSION["aid"];?></td>
            <td><?php echo $_SESSION["em"];?></td>
            <td><button type="button" class="btn btn-sm btn-info"><span class="fa fa-edit"></span> Edit</button> | <button type="button" class="btn btn-sm btn-danger"><span class="fa fa-trash"></span> Delete</button></td>
          </tr>
          
        </tbody>
      </table>
    </div>
  </div>
</div>
</section>
 <!-- footer -->

  <!-- / footer -->
</section>

<!--main content end-->
</section>
