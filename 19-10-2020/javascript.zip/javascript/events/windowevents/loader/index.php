<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Online Pets Systems Provide Service for All Pets | Rajkot | Ahemdabad</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <style>
        #loader {
            width: 450px;
            height: 450px;
            position: absolute;
            left: 32%;
            top: 10%;
            background-image: url('images/loader2.gif');
            background-size: 450px 450px;
        }
        
        #mydiv {
            display: none;
        }
    </style>
    <script type="text/javascript">
        var myVar;

        function myFunction() {
            myVar = setTimeout(showPage, 5000);
        }

        function showPage() {
            document.getElementById("loader").style.display = "none";
            document.getElementById("mydiv").style.display = "block";
        }
    </script>
</head>

<body onload="myFunction()">
    <div id="loader"></div>

    <!-- main divisons start -->

    <div id="mydiv">

        <h1 align="center">We hard work to Comming Soon!</h1>
        <p align='center'>Please Like , subscrive us obn youtube <a href="">Brijesh Pandey</a></p>



    </div>
</body>

</html>