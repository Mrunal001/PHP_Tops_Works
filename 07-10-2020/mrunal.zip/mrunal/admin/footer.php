  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2012-22 Mvc Admin. All rights reserved | Design by <a href="#">Mvc</a></p>
			</div>
		  </div>