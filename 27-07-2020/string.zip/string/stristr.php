<?php

echo stristr("Hello world","world")."<br>";

echo stristr("Hello world","llo")."<br>";

echo stristr("Hello world","hello")."<br>"; //case insensitive follow




?>