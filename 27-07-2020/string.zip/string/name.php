<?php
$name="My name is : Brijesh";

echo $name."<br>";

echo var_dump($name);


?>