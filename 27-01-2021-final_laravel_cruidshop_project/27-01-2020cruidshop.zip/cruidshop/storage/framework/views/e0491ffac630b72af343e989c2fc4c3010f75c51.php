<?php $__env->startSection('title_here'); ?>
Admin:Add Technology Page

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                        
                            <div class="card shadow-lg border-0 rounded-lg mt-5" style="padding:15px !important">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Read  Technology</h3>


                                </div>




                                
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                Read Technology
                            </div>


                            <div class="card-body">
                                <div class="">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                      
                                        
                                        <tbody>

                                        
                                     
                                        
                                        
                                            <tr>
                                                <td>Id :<?php echo e($data->id); ?></td>
                                                </tr>
                                                <tr>
                                                <td>Technology Title :<?php echo e($data->technology_title); ?></td>
                                                </tr>
                                                <tr>
                                                <td>Technology Name :<?php echo e($data->technology_name); ?></td>
                                                </tr>
                                                <tr>
                                                <td>Technology Descriptions :<?php echo e($data->technology_description); ?></td>
                                                </tr>
                                                <tr>

                                                <td><a href='<?php echo e(url("ManageAddtechnology/{$data->id}")); ?>' class="btn btn-dm btn-danger" onclick="return confirm('Are You sure to delete Data')">delete</a>|<a href="#" class="btn btn-dm btn-info">Edit</a></td>

                                            
                                            </tr>
                                        
                                      
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
            </main>
        </div>

        </div>  </div>


        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cruidshop\resources\views/admin/readaddtechnology.blade.php ENDPATH**/ ?>