#feature of oops
  1)class
  2)object 
  3)inheritance
  4)abstarct 
  5)encapsulation
  6)plymorphism

