<div class="content">
 <div class="container-fluid">
     <div class="row">
     <div class="col-md-12 col-xs-12">


<center>
        <img src="<?php echo $baseurl;?>images/404.png" style="width:80%; height: 400px;">



</center>



     </div>
     </div>
 </div></div>