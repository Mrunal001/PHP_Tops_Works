<?php
$array=array("rjt"=>"rajkot","adi"=>"ahemdabad","bard"=>"baroda","vns"=>"varansi");
echo json_encode($array);


?>