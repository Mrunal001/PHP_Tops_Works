<?php
// syntax:
// if(condition)
// {
//    if(condition)

//    {
//        statements;
//    }

// }

// else

// {

//     statements;
// }



$a=15;
$b=10;
if($a>$b)
{
    if($a!=0 && $b!=0)
    {
        echo "a is greater than b and a and b both are positive number";
    }


}


else

{

    echo "a is less than b";
}