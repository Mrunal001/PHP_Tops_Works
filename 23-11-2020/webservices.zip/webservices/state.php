<?php
$array=array("gj"=>"gujrat","up"=>"uttar pradesh","mp"=>"madhya pradesh","ch"=>"chattishgardh");
echo json_encode($array);


?>