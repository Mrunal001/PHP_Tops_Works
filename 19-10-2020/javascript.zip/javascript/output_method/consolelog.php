<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <!-- <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script> -->

    <script type="text/javascript">
        function test()

        {

            var a = 10;
            var b = 20;
            var c = a * b;
            console.log("Multiplications is :" + c)

        }
    </script>
</head>

<body>

    <button type="button" onmouseover="test()">Click </button>
</body>

</html>