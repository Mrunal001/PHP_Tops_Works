<?php

// echo "<h3 align='center'>Hello Maulik";
print("Hello Maulik");

?>