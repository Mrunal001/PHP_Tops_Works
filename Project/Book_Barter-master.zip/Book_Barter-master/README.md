# Book_Barter
A project aimed at easing book sharing among students in an institution
