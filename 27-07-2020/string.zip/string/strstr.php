<?php

echo strstr("Hello world","world")."<br>";

echo strstr("Hello world","llo")."<br>";

echo strstr("Hello world","Hello")."<br>"; //case sensitive follow
?>