<?php

$arr=array(0=>"brijesh",1=>"rajesh",2=>"sagar",3=>"jeet");
print(array_push($arr,"nitesh"));
print_r($arr);




?>