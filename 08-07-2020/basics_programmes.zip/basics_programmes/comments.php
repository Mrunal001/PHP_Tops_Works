<?php

//echo "My name is Brijesh"; single line comments

echo "My name is Brijesh"."<br>"."My name is sanjay"."<br>";


/* multiline comments

echo "My name is Maulik"."<br>"."My name is Mrunal";


*/





?>