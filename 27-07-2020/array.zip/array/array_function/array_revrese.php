<?php
$arr=array(0=>"brijesh",1=>"rajesh",2=>"sagar",3=>"jeet");
print_r(array_reverse($arr));

?>