<?php
$mainurl="http://localhost/task/admin/";
$baseurl="http://localhost/task/admin/assets/";
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Employee management systems</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo $baseurl;?>css/bootstrap.min.css'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo $baseurl;?>css/font-awesome.min.css'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo $baseurl;?>css/style.css'>
    <script src='<?php echo $baseurl;?>js/jquery.js'></script>
    <script src='<?php echo $baseurl;?>js/jquery.bvalidator.min.js'></script>
    <script src='<?php echo $baseurl;?>js/default.min.js'></script>
    <script src='<?php echo $baseurl;?>js/gray.js'></script>
    
    <script src='<?php echo $baseurl;?>js/bootstrap.min.js'></script>
</head>


<body>
            <!-- content panel start here -->
<div class="col-md-12 col-xs-12">


<center>
<a  href="<?php echo $mainurl;?>"><img src="<?php echo $baseurl;?>images/404.png">
<br><br>

<button type="button" class="btn btn-info btn-danger">Go at Home</button>

</a>
</center>



         

</div>


</body>
</html>