<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script>
        function test()

        {

            alert('Yes you apply Onkey press in js')

        }
    </script>
</head>

<body>

    <form>
        Press on controll :<input type="text" name="nm" placeholder="Press any key" onkeypress="test()"><br><br>

        <input type="submit" name="sub" value="Submit">
    </form>

</body>

</html>